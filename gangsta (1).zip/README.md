# gangsta
Gotta to speak gangsta? This bot will hook you up.

![visitors](https://visitor-badge.glitch.me/badge?page_id=SouravJohar.visitor-badge)

# Watch the video [here.](https://youtu.be/5nhdxpoicW4)

## Dependencies:
  * requests
  * lxml
  * beautifulsoup4
  
> You: Hey! What's up?

> Bot: Yo dawwwwg! Whatz good?

### Usage:
 * Make a telegram bot and get the API token, and paste it inside `config.cfg`
 * ```$ python server.py```
